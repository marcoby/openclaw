# MEMORY.md - Long-Term Memory

- User: Von (America/Los_Angeles). Company: Marcoby.
- Purpose: Build and use Tech Buddy to help run Marcoby (ops, comms, projects, and general assistance).
- Stack: Microsoft 365 for communications and documents.
- Keep BOOTSTRAP.md for reference per user preference (set on 2026-02-01).
