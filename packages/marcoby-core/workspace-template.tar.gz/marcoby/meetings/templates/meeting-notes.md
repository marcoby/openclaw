# Meeting Notes

- Meeting: <name>
- Date/Time: <yyyy-mm-dd hh:mm tz>
- Attendees: <names>
- Objective: <what success looks like>

Agenda
1. <topic>
2. <topic>

Notes
- <bullets>

Decisions
- <decision> — owner, timestamp

Action Items
- [ ] <task> — owner, due <date>
- [ ] <task> — owner, due <date>
