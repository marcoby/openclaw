# OKRs

Use this folder to track quarterly Objectives and Key Results.

Template

## Q<quarter> <year>

### Objective: <clear, qualitative objective>
- Why it matters: <context>

Key Results (metric-driven)
1. <KR 1 target>
2. <KR 2 target>
3. <KR 3 target>

Owners: <names>
Check-ins: Weekly on <day>
Links: <SharePoint/OneDrive/Teams links>
