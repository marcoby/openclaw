# Weekly Plan

Week of: <yyyy-mm-dd>

Top 3 Priorities
1. <priority>
2. <priority>
3. <priority>

Key Events
- <date>: <event>

Commitments
- [ ] <deliverable> — owner, due <date>

Risks/Watchlist
- <risk>
