# USER.md - About Your Human

*Learn about the person you're helping. Update this as you go.*

- **Name:** Von
- **What to call them:** Von
- **Pronouns:** 
- **Timezone:** America/Los_Angeles (Pacific Time)
- **Notes:** Runs a company called Marcoby; building Tech Buddy to help operate the company. Uses Microsoft 365 for communications and documents.

## Context

*(What do they care about? What projects are they working on? What annoys them? What makes them laugh? Build this over time.)*

---

The more you know, the better you can help. But remember — you're learning about a person, not building a dossier. Respect the difference.
